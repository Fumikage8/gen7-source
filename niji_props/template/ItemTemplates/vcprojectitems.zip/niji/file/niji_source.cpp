﻿//======================================================================
/**
 * @file $fileinputname$.cpp
 * @date $time$
 * @author $username$
 * @brief 簡単な説明
 * @par Copyright
 * (C)1995-2015 GAME FREAK inc. All Rights Reserved.
 */
//======================================================================

#include <macro/include/gfl2_Macros.h>

GFL_NAMESPACE_BEGIN(mynamespace)

/**
 * @enum Enum
 * 列挙体の説明
 */
enum PrivateEnum
{
  //! 列挙体の各要素へのコメント
  EnumItem1 = 0x00,

  //! 列挙体の各要素へのコメント
  EnumItem2 = 0x01
};

/**
 * @struct tStruct1
 * @brief  構造体の説明
 */
struct privateStruct
{
  //! メンバ1の説明
  int member1;
};

/**
 * @class MyClass
 * @brief クラスの説明
 */
class PrivateClass
{
  GFL_FORBID_COPY_AND_ASSIGN(PrivateClass);

public:
  /**
   * @fn
   * ここに関数の説明を書く
   * @brief 要約説明
   * @param[in] var1 var1の説明
   * @param[out] var2 var2の説明
   * @param[in,out] var3 var3の説明
   * @return 戻り値の説明
   * @sa 参照すべき関数を書けばリンクが貼れる
   * @detail 詳細な説明
   */
  int MyFunc(int var1, char *var2, char *var3[]);

private:
  //! 変数へのコメント
  int m_variable;
};

GFL_NAMESPACE_END(mynamespace)
