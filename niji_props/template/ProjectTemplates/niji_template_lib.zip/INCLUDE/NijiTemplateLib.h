//
// CTR - Library : NijiTemplateLib
//

#ifndef	__NijiTemplateLib_H__
#define	__NijiTemplateLib_H__

//
// global symbol declared.
//
extern int g_NijiTemplateLib;

//
// function prototypes.
//
void	NijiTemplateLib(void);

//
// class definition.
//
class CNijiTemplateLib
{
public:
	CNijiTemplateLib();
};

#endif	// __NijiTemplateLib_H__
