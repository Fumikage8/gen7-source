//
// CTR - Library : NijiTemplateLib
//

#include <stdio.h>

#ifdef GF_PLATFORM_CTR

#include <nn/os.h>
#include <nn/dbg.h>

#endif //GF_PLATFORM_CTR

#include "../include/NijiTemplateLib.h"

//
// global symbol definition.
//
int g_NijiTemplateLib = 0;

//
// function definition.
//
void	NijiTemplateLib(void)
{

}

//
// class definition.
//

// constructor
CNijiTemplateLib::CNijiTemplateLib()
{

}

