//
// CTR - Library : template
//

#include <stdio.h>

//#include <nn/os.h>
//#include <nn/dbg.h>
#include "../include/gfl2_template.h"

//
// global symbol definition.
//
int g_template = 0;

//
// function definition.
//
void	GFL2Template(void)
{

}

//
// class definition.
//

// constructor
CGFL2Template::CGFL2Template()
{

}

