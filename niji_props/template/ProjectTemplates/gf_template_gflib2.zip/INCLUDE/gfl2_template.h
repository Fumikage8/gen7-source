//
// CTR - Library : template
//

#ifndef	__gfl2_template_H__
#define	__gfl2_template_H__

//
// global symbol declared.
//
extern int g_template;

//
// function prototypes.
//
void	GFL2Template(void);

//
// class definition.
//
class CGFL2Template
{
public:
	CGFL2Template();
};

#endif	// __gfl2_template_H__
