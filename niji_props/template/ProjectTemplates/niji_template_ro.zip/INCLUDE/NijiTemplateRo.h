//
// CTR - Ro Module : NijiTemplateRo
//

#ifndef	__NijiTemplateRo_H__
#define	__NijiTemplateRo_H__


#ifdef GF_PLATFORM_CTR

//
// function prototypes.
//
extern "C" NN_DLL_EXPORT void	NijiTemplateRo(void);

#endif  //#ifdef GF_PLATFORM_CTR


#endif	// __NijiTemplateRo_H__
