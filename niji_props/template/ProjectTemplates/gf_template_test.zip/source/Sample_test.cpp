﻿/**
 * @file Sample_test.cpp
 * @date 2015/07/28 20:51:58
 * @author araki_syo
 * @brief gf_template_testを用いたテストのサンプル
 * @par Copyright
 * (C)1995-2015 GAME FREAK inc. All Rights Reserved.
 */

#if defined(GF_PLATFORM_CTR)
#include <nn/nlib/testing/testing.h>
#elif defined(GF_PLATFORM_WIN32)
#include <gtest/gtest.h>
#endif

/**
 * @brief 必ず失敗するテストケース
 * @note GoogleTestの利用法については http://opencv.jp/googletestdocs/index.html を参照してください
 */
TEST(Sample, TriviallyFail){
  EXPECT_TRUE(false); // EXPECT_* のテストが失敗しても他のテストは実行されます
  ASSERT_TRUE(false); // ASSERT_* のテストが失敗した場合はその時点でテストを中断します
}
