﻿/**
 * @file Main.cpp
 * @date 2015/07/28
 * @author araki_syo
 * @brief テストプロジェクトのエントリポイント
 * @par Copyright
 * (C)1995-2015 GAME FREAK inc. All Rights Reserved.
 */

#include <stdio.h>

#if defined(GF_PLATFORM_CTR)

#include <nn/os.h>
#include <nn/dbg.h>

#include <nn/nlib/testing/testing.h>

extern "C" int nnMain(int argc, char *argv[])
{
  ::testing::InitNintendoTest(&argc, argv);
  return RUN_ALL_TESTS();
}
#elif defined(GF_PLATFORM_WIN32)

#include <gtest/gtest.h>

int main(int argc, char *argv[])
{
  testing::InitGoogleTest(&argc, argv);
  RUN_ALL_TESTS();
  getchar();
}

#endif
